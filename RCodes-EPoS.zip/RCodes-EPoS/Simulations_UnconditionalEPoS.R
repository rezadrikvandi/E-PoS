#################################################################################################################
#Unconditional E-PoS (i.e., with deterministic S);
#################################################################################################################

#############################################################################################################################
#You may wish to customise the two directories used at the bottom of the code for saving the simulation results into your computer;
#############################################################################################################################
library(MASS);
library(glmnet);
library(mvtnorm);
library(pls);
#################################################################################################################
itr <- 2; #simulation iterations, here it is set to 2 for a quicker run of the simulation for n=100 and p=500;
#################################################################################################################
#Simulation settings;
n <- 150; #it will be split later: 67% for training data (i.e, 100) and 33% for test data;
#n <- 299; #it will be split later: 67% for training data (i.e, 200) and 33% for test data;
#n <- 448; #it will be split later: 67% for training data (i.e, 300) and 33% for test data;
p <- 500;  #the number of regression parameters;
pstar <- 20; #the sparsity index in the simulation;
beta <- rnorm(p,0,1);  #generate the true regression parameters;
for(j in (pstar+1):p){beta[j]<-0;} #applying the sparsity index;
beta0 <- beta[1];  #the true intercept;
beta1 <- beta[-1];  #the true regression parameters associated with covariates;
sigma <- 1;
sigma2 <- 1;
Y <- numeric(n);
X <- matrix(0,n,p-1); #X <- vector("list",p-1);
e <- matrix(0,n,1);
k_min <- 10; #minimun value to find optimal K using CV;
k_max <- 400; #maximum value to find optimal K using CV, considering the size of training data;
k_step <- 23; #step to search for optimal k;
kk <- numeric(itr); #to save the optimal k in each iteration;
nselcov <- numeric(itr); #to save the number of selected covariates in each iteration;
MABpcr<- numeric(itr);
MABlinearReg<- numeric(itr);
MABlasso <- numeric(itr);
MABridge <- numeric(itr);
MABnew <- numeric(itr); #new refers to the new method "E-PoS";
sigma2pcr<- numeric(itr);
sigma2linearReg<- numeric(itr);
sigma2lasso <- numeric(itr);
sigma2ridge <- numeric(itr);
sigma2new <- numeric(itr);
MSPEpcr<- numeric(itr);
MSPElinearReg<- numeric(itr);
MSPElasso <- numeric(itr);
MSPEridge <- numeric(itr);
MSPEnew <- numeric(itr);
AvgCovCI <- numeric(itr);
AvgLengthCI <- numeric(itr);
AvgPowerTest_min <- numeric(itr);
AvgPowerTest_max <- numeric(itr);
TestStat_Min <- numeric(itr);
TestStat_Max <- numeric(itr);
LambdaHat <- numeric(itr);
min_betaS <- numeric(itr);
min_betaShat <- numeric(itr);
max_betaU <- numeric(itr);
#################################################################################################################
#A function to obtain "Index_of_Xs" and "Lambda_Lasso", which are needed for the main function called "EPoS";
#################################################################################################################
Function_Index_of_Xs <- function(X.train,Y.train)
{
  dimnames(X.train) <- list(rownames(X.train, do.NULL = TRUE),colnames(X.train, do.NULL = FALSE, prefix = "X"));
  #Negahban et al (2012) approach to the lambda selection; 
  lambda_gen <- numeric(10000);
  I_n <- diag(nn,x=rep(1,nn));
  sigma2 <- 1;
  eps <- rmvnorm(10000,mean=rep(0,nn),sigma=sigma2*I_n);
  for(i in 1:10000)
  {
    lambda_gen[i] <- 2*max(t(X.train)%*%eps[i,]);
  }
  lambda_n <- mean(lambda_gen)/nn;
  lambda_max <- max(lambda_n,sqrt(log(p)/nn));
  #Apply lasso to get "Index_of_Xs" and an optimal Lambda_Lasso based on X.train and Y.train;
  M1 <- glmnet(X.train,Y.train, family="gaussian", alpha=1);
  betahat1 <- coef(M1, s=lambda_max);
  b1 <- cbind(beta,betahat1);
  b1new <- apply(b1, 1, function(row) all(row!=0));
  estimate1 <- b1[b1new,];
  leng <- length(estimate1);
  #Index_Xs will be required for constructing Xs and Xu;
  Index_Xs <- row.names(estimate1);
  Index_Xs <- c(Index_Xs);
  Index_Xs <- gsub("[a-zA-Z ]", "", Index_Xs);
  Index_Xs <- Index_Xs[-1];
  Index_Xs <- as.numeric(Index_Xs);
  return(list(Index_Xs,lambda_max));
}
#################################################################################################################
for(rep in 1:itr)
{
  nselect=0;
  while(nselect<2 | nselect==p)
  {
   for(i in 1:n)
   {
     n_covariates <- p-1;
     X[i,] <- rnorm(n_covariates,0,1);
     e[i] <- rnorm(1,0,sigma);
     Y[i] <- beta0+t(X[i,])%*%beta1+e[i];  
   }
   train_rows <- sample(1:n, 0.67*n);
    
   X.train <- X[train_rows, ];
   dimnames(X.train) <- list(rownames(X.train, do.NULL = TRUE),colnames(X.train, do.NULL = FALSE, prefix = "X"))
   X.test <- X[-train_rows, ];
   dimnames(X.test) <- list(rownames(X.test, do.NULL = TRUE),colnames(X.test, do.NULL = FALSE, prefix = "X"))
    
   Y.train <- Y[train_rows];
   Y.test <- Y[-train_rows];
   
   nn <- nrow(X.train); #the sample size as in the training data;
   
   # To obtain the "Index_of_Xs" and "Lambda_Lasso" based on X.train and Y.train from the above function;
   Lasso_Selection <- Function_Index_of_Xs(X.train,Y.train);
   Index_of_Xs <- Lasso_Selection[[1]];
   Lambda_Lasso <- Lasso_Selection[[2]];
   
   nselect <- length(Index_of_Xs);
   nselcov[rep] <- nselect;
   }
  
  
  # The main function to apply the new method "E-PoS" to the data;
  EPoS <- function(X.train,Y.train,X.test,Y.test,Index_of_Xs,Lambda_Lasso,k)
  {
    nn <- nrow(X.train); #sample size as in the training data;
    #Process of constructing Xs and Xu;
    Xu <- X.train; #just an initial assignment here to start the process;
    Xs <- X.train[,1]; #just an initial assignment here to start the process;
    Index_Xs <- Index_of_Xs;
    q <- length(Index_Xs); #the number of selected covariates excluding the intercept column;
    length_Index_Xs <- q; #the number of selected covariates excluding the intercept column;
    j <- Index_Xs[1];
    for(i in 1:length_Index_Xs)
    {
      Xu <- Xu[,-j];
      j <- Index_Xs[i+1]-i;
      Xs <- cbind(Xs,X.train[,Index_Xs[i]]);
    }
    Xs <- Xs[,-1];
    Xs <- matrix(c(Xs),nn,length_Index_Xs);
    dimnames(Xs) <- list(rownames(Xs, do.NULL = TRUE),colnames(Xs, do.NULL = FALSE, prefix = "Xs"));
    Int <- rep(1,nn);
    Xs <- cbind(Int,Xs); #add a column of ones for the intercept;
    Xs_WithoutIntercept <- Xs[,-1];
    
    #Finding beta_s and beta_u;
    q <- length(Index_Xs); #the number of selected variables;
    beta_u <- beta1; #just an initial assignment;
    beta_s <- beta0; #just an initial assignment;
    j <- Index_Xs[1];
    for(i in 1:length_Index_Xs)
     {
      beta_u <- beta_u[-j];
      j <- Index_Xs[i+1]-i;
      beta_s <- c(beta_s,beta1[Index_Xs[i]]);
     }

    Xu_decomposition=svd(Xu,nv=ncol(Xu),LINPACK=FALSE);
    
    if(ncol(Xu)-length(Xu_decomposition$d)!=0)
    {
      add1=matrix(0,length(Xu_decomposition$d),ncol(Xu)-length(Xu_decomposition$d));
      add2=matrix(0,ncol(Xu)-length(Xu_decomposition$d),ncol(Xu));
      U=cbind(Xu_decomposition$u,add1);
      D=rbind(cbind(diag(Xu_decomposition$d),add1),add2);
      P=U%*%D;
      V=Xu_decomposition$v;
    }else{
      U=Xu_decomposition$u;
      D=diag(Xu_decomposition$d);
      P=U%*%D;
      V=Xu_decomposition$v;
    }
    
    # for estimation in the E-PoS model and its bias evaluation;
    if(k>1 & k<ncol(U))
    {
      U_k <- U[,1:k];
      D_k <- D[1:k,1:k];
      V_k <- V[1:k,1:k];
      P_k <- P[,1:k];
    } else{
      U_k <- U;
      D_k <- D;
      V_k <- V;
      P_k <- P;
    }
    
    # reparametrisation from lambda to log(lambda) to avoid parameter constraint in maximisation of the profile likelihood; 
    profile_likelihood <- function(par)
    {
      lambdaa <- exp(par); #the reparametrisation;
      I_n=diag(nn,x=rep(1,nn));
      Sigma_lambdaa <- I_n + (P_k%*%t(V_k)%*%V_k%*%t(P_k))*lambdaa; 
      H <- Xs%*%ginv(t(Xs)%*%ginv(Sigma_lambdaa)%*%Xs)%*%t(Xs)%*%ginv(Sigma_lambdaa);
      e <- (I_n-H)%*%Y.train;
      l_p=(-1/2)*(log(det(Sigma_lambdaa)))-(nn/2)*(log(t(e)%*%ginv(Sigma_lambdaa)%*%e));
      return(c(-l_p));
    }
    
    par_hat <- try(nlminb(0,profile_likelihood,control=list(iter.max=10000))$par,silent=TRUE);
    
    if(typeof(par_hat)=="character")
    {
      return(c(NA,NA,NA,NA,NA,NA,NA,NA,NA,NA,NA,NA,NA,NA));
    } else{
    lambda_hat <- exp(par_hat);
    I_n=diag(nn,x=rep(1,nn));
    Sigma_lambda_hat <- I_n + (P_k%*%t(V_k)%*%V_k%*%t(P_k))*lambda_hat; 
    betahat_s_marginal <- ginv(t(Xs)%*%ginv(Sigma_lambda_hat)%*%Xs)%*%t(Xs)%*%ginv(Sigma_lambda_hat)%*%Y.train;
    sigma2_hat_marginal <- (1/nn)*t(Y.train-Xs%*%betahat_s_marginal)%*%ginv(Sigma_lambda_hat)%*%(Y.train-Xs%*%betahat_s_marginal);
    var_betahat_s_marginal <- c(sigma2_hat_marginal)*ginv(t(Xs)%*%ginv(Sigma_lambda_hat)%*%Xs);
    
    LambdaHat[rep] <- lambda_hat;
    
    #Construct confience intervals for beta_s using the E-PoS approach;
    CI <- matrix(0,length(betahat_s_marginal),2);
    coverage <- numeric(length(betahat_s_marginal));
    lenghts <- numeric(length(betahat_s_marginal));
    for(j in 1:length(betahat_s_marginal))
    {
      CI[j,] <- c(betahat_s_marginal[j]-qnorm(0.975,0,1)*sqrt(var_betahat_s_marginal[j,j]),betahat_s_marginal[j]+qnorm(0.975,0,1)*sqrt(var_betahat_s_marginal[j,j]));
      #calculate the length of the CI for beta_s_j;
      lenghts[j] <- CI[j,2]-CI[j,1]; 
      #calculate the coverage probability of the CI for beta_s_j;
      if(beta_s[j]>=CI[j,1] & beta_s[j]<=CI[j,2])
      {
        coverage[j] <- 1;
      } else
      {
        coverage[j] <- 0;
      }
    }
    
    #conduct hypothesis test for minimum beta_s;
    beta_min_index <- which.min(abs(beta_s));
    beta_min <- beta_s[beta_min_index];
    beta_min_hat <- betahat_s_marginal[beta_min_index];
    sd_beta_min_hat <- sqrt(var_betahat_s_marginal[beta_min_index,beta_min_index]);
    test_stat_min <- (beta_min_hat)/sd_beta_min_hat;
    if(abs(test_stat_min)>=qnorm(0.975,0,1))
    {
      testpower_min <- 1;
    } else
    {
      testpower_min <- 0;
    } 
    
    #conduct hypothesis test for maximum beta_s;
    beta_max_index <- which.max(abs(beta_s));
    beta_max <- beta_s[beta_max_index];
    beta_max_hat <- betahat_s_marginal[beta_max_index];
    sd_beta_max_hat <- sqrt(var_betahat_s_marginal[beta_max_index,beta_max_index]);
    test_stat_max <- (beta_max_hat)/sd_beta_max_hat;
    if(abs(test_stat_max)>=qnorm(0.975,0,1))
    {
      testpower_max <- 1;
    } else
    {
      testpower_max <- 0;
    } 
    
    AvgCov <- mean(coverage);
    AvgLeng <- mean(lenghts);
    AvgPow_min <- testpower_min;
    AvgPow_max <- testpower_max;
    tstat_min <- test_stat_min;
    tstat_max <- test_stat_max;
    minbetaS_hat <- beta_min_hat;
    
    ####################################
    # The bias of the new method "E-PoS";
    bb_EPoS <- cbind(beta_s,betahat_s_marginal);
    MAB_NewMethod <- mean(abs(bb_EPoS[,2]-bb_EPoS[,1]));
    
    ####################################
    # for prediction error on the test data;
    n_test <- nrow(X.test);
    Xu_test <- X.test; #just an initial assignment;
    Xs_test <- X.test[,1]; #just an initial assignment;
    j=Index_Xs[1];
    for(i in 1:length_Index_Xs)
    {
      Xu_test=Xu_test[,-j];
      j=Index_Xs[i+1]-i;
      Xs_test=cbind(Xs_test,X.test[,Index_Xs[i]]);
    }
    Xs_test <- Xs_test[,-1];
    Int_test <- rep(1,n_test);
    Xs_test <- cbind(Int_test,Xs_test); #add a column of ones for the intercept;
    
    Xu_test_decomposition=svd(Xu_test,nv=ncol(Xu_test),LINPACK=FALSE);
    
    if(ncol(Xu_test)-length(Xu_test_decomposition$d)!=0)
    {
      add1_test=matrix(0,length(Xu_test_decomposition$d),ncol(Xu_test)-length(Xu_test_decomposition$d));
      add2_test=matrix(0,ncol(Xu_test)-length(Xu_test_decomposition$d),ncol(Xu_test));
      U_test=cbind(Xu_test_decomposition$u,add1_test);
      D_test=rbind(cbind(diag(Xu_test_decomposition$d),add1_test),add2_test);
      P_test=U_test%*%D_test;
      V_test=Xu_test_decomposition$v;
    }else{
      U_test=Xu_test_decomposition$u;
      D_test=diag(Xu_test_decomposition$d);
      P_test=U_test%*%D_test;
      V_test=Xu_test_decomposition$v;
    }
    
    if(k>1 & k<ncol(U_test))
    {
      U_k_test <- U_test[,1:k];
      D_k_test <- D_test[1:k,1:k];
      V_k_test <- V_test[1:k,1:k];
      P_k_test <- P_test[,1:k];
    }else{
      U_k_test <- U_test;
      D_k_test <- D_test;
      V_k_test <- V_test;
      P_k_test <- P_test;
    }
    
    # Prediction using the new method "E-PoS";
    b_k_hat <- lambda_hat*(V_k%*%t(P_k)%*%ginv(Sigma_lambda_hat))%*%(Y.train-Xs%*%betahat_s_marginal);
    Yhat_NewMethod <- Xs_test%*%betahat_s_marginal + P_k_test%*%t(V_k_test)%*%b_k_hat;
    MSPE_NewMethod <- mean((Y.test - Yhat_NewMethod)^2);
    
    
    #Naive least squares regression on the lasso selected covariates;
    datass <- data.frame(Y.train,Xs_WithoutIntercept);
    M0 <- lm(Y.train~Xs_WithoutIntercept,data=datass);
    betahat_s_LS <- M0$coefficients;
    b0 <- cbind(beta_s,betahat_s_LS);
    MAB_LinearReg <- mean(abs(b0[,2]-b0[,1]));
    #prediction error of the naive least squares regression;
    Yhat_LinearReg <- Xs_test%*%betahat_s_LS;
    MSPE_LinearReg <- mean((Y.test - Yhat_LinearReg)^2);
    #Estimate of sigma2 using the naive least squares regression;
    sigma2_LinearReg <- (sum((Y.test - Yhat_LinearReg)^2))/(nn-1);
    }
    return(c(MAB_NewMethod,sigma2_hat_marginal,MSPE_NewMethod,AvgCov,AvgLeng,AvgPow_min,AvgPow_max,tstat_min,tstat_max,lambda_hat,minbetaS_hat,MAB_LinearReg,sigma2_LinearReg,MSPE_LinearReg));
  }
  
  
  
  #Cross Validation for the proposed E-PoS method in order to select the optimal k;
  CV_EPoS <- function(X.train,Y.train,X.test,Y.test,Index_of_Xs,Lambda_Lasso,k)
  {
    nn <- nrow(X.train); #sample size as in the CV training data;
    #Process of constructing Xs and Xu;
    Xu <- X.train; #just an initial assignment here to start the process;
    Xs <- X.train[,1]; #just an initial assignment here to start the process;
    Index_Xs <- Index_of_Xs;
    q <- length(Index_Xs); #the number of selected covariates excluding the intercept column;
    length_Index_Xs <- q; #the number of selected covariates excluding the intercept column;
    j <- Index_Xs[1];
    for(i in 1:length_Index_Xs)
    {
      Xu <- Xu[,-j];
      j <- Index_Xs[i+1]-i;
      Xs <- cbind(Xs,X.train[,Index_Xs[i]]);
    }
    Xs <- Xs[,-1];
    Xs <- matrix(c(Xs),nn,length_Index_Xs);
    dimnames(Xs) <- list(rownames(Xs, do.NULL = TRUE),colnames(Xs, do.NULL = FALSE, prefix = "Xs"));
    Int <- rep(1,nn);
    Xs <- cbind(Int,Xs); #add a column of ones for the intercept;
    Xs_WithoutIntercept <- Xs[,-1];

    Xu_decomposition=svd(Xu,nv=ncol(Xu),LINPACK=FALSE);
    
    if(ncol(Xu)-length(Xu_decomposition$d)!=0)
    {
      add1=matrix(0,length(Xu_decomposition$d),ncol(Xu)-length(Xu_decomposition$d));
      add2=matrix(0,ncol(Xu)-length(Xu_decomposition$d),ncol(Xu));
      U=cbind(Xu_decomposition$u,add1);
      D=rbind(cbind(diag(Xu_decomposition$d),add1),add2);
      P=U%*%D;
      V=Xu_decomposition$v;
    }else{
      U=Xu_decomposition$u;
      D=diag(Xu_decomposition$d);
      P=U%*%D;
      V=Xu_decomposition$v;
    }
    
    # for estimation in the E-PoS model and its bias evaluation;
    if(k>1 & k<ncol(U))
    {
      U_k <- U[,1:k];
      D_k <- D[1:k,1:k];
      V_k <- V[1:k,1:k];
      P_k <- P[,1:k];
    } else{
      U_k <- U;
      D_k <- D;
      V_k <- V;
      P_k <- P;
    }
    
    # reparametrisation from lambda to log(lambda) to avoid parameter constraint in maximisation of the profile likelihood; 
    profile_likelihood <- function(par)
    {
      lambdaa <- exp(par); #the reparametrisation;
      I_n=diag(nn,x=rep(1,nn));
      Sigma_lambdaa <- I_n + (P_k%*%t(V_k)%*%V_k%*%t(P_k))*lambdaa; 
      H <- Xs%*%ginv(t(Xs)%*%ginv(Sigma_lambdaa)%*%Xs)%*%t(Xs)%*%ginv(Sigma_lambdaa);
      e <- (I_n-H)%*%Y.train;
      l_p=(-1/2)*(log(det(Sigma_lambdaa)))-(nn/2)*(log(t(e)%*%ginv(Sigma_lambdaa)%*%e));
      return(c(-l_p));
    }
    
    par_hat <- try(nlminb(0,profile_likelihood,control=list(iter.max=10000))$par,silent=TRUE);
    
    if(typeof(par_hat)=="character")
    {
      return(NA);
    } else{
      if(exp(par_hat)==0)
      {
        return(NA);
    } else{
    lambda_hat <- exp(par_hat);
    I_n=diag(nn,x=rep(1,nn));
    Sigma_lambda_hat <- I_n + (P_k%*%t(V_k)%*%V_k%*%t(P_k))*lambda_hat; 
    betahat_s_marginal <- ginv(t(Xs)%*%ginv(Sigma_lambda_hat)%*%Xs)%*%t(Xs)%*%ginv(Sigma_lambda_hat)%*%Y.train;
    sigma2_hat_marginal <- (1/nn)*t(Y.train-Xs%*%betahat_s_marginal)%*%ginv(Sigma_lambda_hat)%*%(Y.train-Xs%*%betahat_s_marginal);
    var_betahat_s_marginal <- c(sigma2_hat_marginal)*ginv(t(Xs)%*%ginv(Sigma_lambda_hat)%*%Xs);
    
    # compute the prediction error on validation data;
    n_testCV <- nrow(X.test);
    Xu_test <- X.test;
    j=Index_Xs[1];
    Xs_test <- X.test[,1];
    for(i in 1:length_Index_Xs)
    {
      Xu_test=Xu_test[,-j];
      j=Index_Xs[i+1]-i;
      Xs_test=cbind(Xs_test,X.test[,Index_Xs[i]]);
    }
    Xs_test <- Xs_test[,-1];
    Int_test <- rep(1,n_testCV);
    Xs_test <- cbind(Int_test,Xs_test); #add a column of ones for the intercept;
    
    Xu_test_decomposition=svd(Xu_test,nv=ncol(Xu_test),LINPACK=FALSE);
    
    if(ncol(Xu_test)-length(Xu_test_decomposition$d)!=0)
    {
      add1_test=matrix(0,length(Xu_test_decomposition$d),ncol(Xu_test)-length(Xu_test_decomposition$d));
      add2_test=matrix(0,ncol(Xu_test)-length(Xu_test_decomposition$d),ncol(Xu_test));
      U_test=cbind(Xu_test_decomposition$u,add1_test);
      D_test=rbind(cbind(diag(Xu_test_decomposition$d),add1_test),add2_test);
      P_test=U_test%*%D_test;
      V_test=Xu_test_decomposition$v;
    }else{
      U_test=Xu_test_decomposition$u;
      D_test=diag(Xu_test_decomposition$d);
      P_test=U_test%*%D_test;
      V_test=Xu_test_decomposition$v;
    }
    
    if(k>1 & k<ncol(U_test))
    {
      U_k_test <- U_test[,1:k];
      D_k_test <- D_test[1:k,1:k];
      V_k_test <- V_test[1:k,1:k];
      P_k_test <- P_test[,1:k];
    }else{
      U_k_test <- U_test;
      D_k_test <- D_test;
      V_k_test <- V_test;
      P_k_test <- P_test;
    }
    
    # Prediction for the validation data;
    b_k_hat <- lambda_hat*(V_k%*%t(P_k)%*%ginv(Sigma_lambda_hat))%*%(Y.train-Xs%*%betahat_s_marginal);
    Yhat_NewMethodCV <- Xs_test%*%betahat_s_marginal + P_k_test%*%t(V_k_test)%*%b_k_hat;
    MSPE_NewMethodCV <- mean((Y.test - Yhat_NewMethodCV)^2);
    return(MSPE_NewMethodCV);
   }}
  }
  
  
  
  # 10-fold cross validation to select k for the new method "E-PoS";
  CVresults <- c(0,0); 
  q <- length(Index_of_Xs); #the number of selected variables by ignoring the intercept;
  k_max2 <- min(k_max,p-q); #to avoid overrunning in low-dimensional situations;
  for(k in seq(k_min,k_max2,k_step)){
    #Randomly shuffle the train data to partition for CV;
    X.trainCV <- X.train[sample(nrow(X.train)),];
    Y.trainCV <- Y.train[sample(length(Y.train))];
    #Create 10 equally size folds;
    breaks <- nrow(X.trainCV)*0.1;
    folds <- cut(seq(1,nrow(X.trainCV)),breaks=breaks,labels=FALSE);
    
    #Perform 10 fold cross validation;
    MSPE_CV <- numeric(breaks);
    for(i in 1:breaks){
      #Segement your data by fold using the which() function; 
      testIndexes <- which(folds==i,arr.ind=TRUE);
      XtrainCV_train <- X.trainCV[-testIndexes, ];
      XtrainCV_valid <- X.trainCV[testIndexes, ];
      YtrainCV_train <-  Y.trainCV[-testIndexes];
      YtrainCV_valid <-  Y.trainCV[testIndexes];
      MSPE_CV[i] <- CV_EPoS(X.train=XtrainCV_train,Y.train=YtrainCV_train,X.test=XtrainCV_valid,Y.test=YtrainCV_valid,Index_of_Xs=Index_of_Xs,Lambda_Lasso=Lambda_Lasso,k=k);
    }
    if(length(na.omit(MSPE_CV)) < floor(breaks))
    {
      kCV <- c(k,NA);
    } else{
      kCV <- c(k,mean(MSPE_CV, na.rm=TRUE));
    }
    CVresults <- rbind(CVresults,kCV);
  }
  
  if(nrow(CVresults)>1){
    CVresult <- CVresults;
    CVresult <- CVresult[order(CVresult[,2]),];
    CVresult <- CVresult[complete.cases(CVresult),];
    CVresult <- as.matrix(CVresult);
    CVresult <- t(CVresult);
    if(!is.null(nrow(CVresult)) & nrow(CVresult)>1)
    {
      CVresult <- CVresults;
      CVresult <- CVresult[order(CVresult[,2]),];
      CVresult <- CVresult[complete.cases(CVresult),];
      CVresult <- matrix(CVresult,nrow(CVresult),2);
      stopvalue <- NA;
      i=2;
      while(is.na(stopvalue))
      {
        kk[rep] <- CVresult[i,1];
        kkk = kk[rep];
        Results_NewMethod <- EPoS(X.train=X.train,Y.train=Y.train,X.test=X.test,Y.test=Y.test,Index_of_Xs=Index_of_Xs,Lambda_Lasso=Lambda_Lasso,k=kkk);
        stopvalue <- Results_NewMethod[1];
        i <- i+1;
        if(i>=nrow(CVresult))
        {
          break;
        }
      }
      MAB_NewMethod <- Results_NewMethod[1];
      sigma2_hat_marginal <- Results_NewMethod[2];
      MSPE_NewMethod <- Results_NewMethod[3];
      AvgCoverage <- Results_NewMethod[4]; 
      AvgLength <- Results_NewMethod[5];
      AvgPower_min <- Results_NewMethod[6];
      AvgPower_max <- Results_NewMethod[7];
      TestStatistic_min <- Results_NewMethod[8];
      TestStatistic_max <- Results_NewMethod[9];
      LambdaEst <- Results_NewMethod[10];
      minbetaShat <- Results_NewMethod[11];
      MAB_LinearReg <- Results_NewMethod[12];
      sigma2_LinearReg <- Results_NewMethod[13];
      MSPE_LinearReg <- Results_NewMethod[14];
    } else{
      MAB_NewMethod <- NA;
      sigma2_hat_marginal <- NA;
      MSPE_NewMethod <- NA;
      AvgCoverage <- NA; 
      AvgLength <- NA;
      AvgPower_min <- NA;
      AvgPower_max <- NA;
      TestStatistic_min <- NA;
      TestStatistic_max <- NA;
      LambdaEst <- NA;
      minbetaShat <- NA;
      MAB_LinearReg <- NA;
      sigma2_LinearReg <- NA;
      MSPE_LinearReg <- NA;
    }
  } else{
    MAB_NewMethod <- NA;
    sigma2_hat_marginal <- NA;
    MSPE_NewMethod <- NA;
    AvgCoverage <- NA;
    AvgLength <- NA;
    AvgPower_min <- NA;
    AvgPower_max <- NA;
    TestStatistic_min <- NA;
    TestStatistic_max <- NA;
    LambdaEst <- NA;
    minbetaShat <- NA;
    MAB_LinearReg <- NA;
    sigma2_LinearReg <- NA;
    MSPE_LinearReg <- NA;
  }

  
  #Estimation and prediction using Lasso;
  M1 <- glmnet(X.train,Y.train, family="gaussian", alpha=1, lambda=Lambda_Lasso);
  betahat1 <- coef(M1, s=Lambda_Lasso);
  b1 <- cbind(beta,betahat1);
  b1new <- apply(b1, 1, function(row) all(row!=0));
  estimate1 <- b1[b1new,];
  leng=length(estimate1);
  if(leng>2){
    MAB_Lasso <- mean(abs(estimate1[,2]-estimate1[,1]));
  } else {
    MAB_Lasso <- abs(estimate1[2]-estimate1[1])/2;
  }
  Yhat_Lasso <- predict(M1,X.test,s=Lambda_Lasso);
  MSPE_Lasso <- mean((Y.test - Yhat_Lasso)^2);
  #just an estimate of sigma2 for lasso - not used or reported in the paper;
  Yhat_Lasso2 <- predict(M1,X.train,s=Lambda_Lasso);
  sigma2_Lasso <- (sum((Y.train - Yhat_Lasso2)^2))/(nn-1);
  

  #Estimation and prediction using Ridge regression;
  M2 <- glmnet(X.train,Y.train, family="gaussian", alpha=0);
  CV2 <- cv.glmnet(X.train,Y.train,alpha=0);
  LambdaMin2 <- CV2$lambda.min;
  betahat2 <- coef(M2, s=LambdaMin2);
  b2 <- cbind(beta,betahat2);
  b2new <- apply(b2, 1, function(row) all(row!=0));
  estimate2 <- b2[b2new,];
  MAB_Ridge <- mean(abs(estimate2[,2]-estimate2[,1]));
  Yhat_Ridge <- predict(M2,X.test,s=LambdaMin2);
  MSPE_Ridge <- mean((Y.test - Yhat_Ridge)^2);
  #Estimate of sigma2;
  Yhat_Ridge2 <- predict(M2,X.train,s=LambdaMin2);
  sigma2_Ridge <- (sum((Y.train - Yhat_Ridge2)^2))/(nn-1);
  
  
  #Estimation and prediction using Principal components regression;
  datas <- data.frame(X.train,Y.train);
  M3 <- pcr(Y.train~X.train, data=datas, ncomp=5, validation="CV");
  betahat3 <- coef(M3,intercept=TRUE);
  b3 <- cbind(beta,betahat3);
  MAB_PCR <- mean(abs(b3[,2]-b3[,1]));
  Yhat_PCR <- predict(M3,X.test,ncomp=5);
  MSPE_PCR <- mean((Y.test - Yhat_PCR)^2);
  #Estimate of sigma2;
  Yhat_PCR2 <- predict(M3,X.train,ncomp=5);
  sigma2_PCR <- (sum((Y.train - Yhat_PCR2)^2))/(nn-1);
  
  
  
  #Recalling beta_s and beta_u, needed here just for saving the final results;
  Index_Xs <- Index_of_Xs;
  q <- length(Index_Xs); #the number of selected variables;
  length_Index_Xs <- q; #the number of selected variables;
  beta_u <- beta1; #just an initial assignment;
  beta_s <- beta0; #just an initial assignment;
  j <- Index_Xs[1];
  for(i in 1:length_Index_Xs)
  {
    beta_u <- beta_u[-j];
    j <- Index_Xs[i+1]-i;
    beta_s <- c(beta_s,beta1[Index_Xs[i]]);
  }
  
  #Save the estimates and predition error for all the methods;  
  if(!is.na(MAB_NewMethod))
  {
    MABpcr[rep] <- MAB_PCR;
    MABlinearReg[rep] <- MAB_LinearReg;
    MABridge[rep] <- MAB_Ridge;
    MABlasso[rep] <- MAB_Lasso;
    MABnew[rep] <- MAB_NewMethod;
    sigma2pcr[rep] <- sigma2_PCR;
    sigma2linearReg[rep] <- sigma2_LinearReg;
    sigma2ridge[rep] <- sigma2_Ridge;
    sigma2lasso[rep] <- sigma2_Lasso;
    sigma2new[rep] <- sigma2_hat_marginal;
    MSPEpcr[rep] <- MSPE_PCR;
    MSPElinearReg[rep] <- MSPE_LinearReg;
    MSPEridge[rep] <- MSPE_Ridge;
    MSPElasso[rep] <- MSPE_Lasso;
    MSPEnew[rep] <- MSPE_NewMethod;
    AvgCovCI[rep]  <- AvgCoverage;
    AvgLengthCI[rep] <- AvgLength;
    AvgPowerTest_min[rep] <- AvgPower_min;
    AvgPowerTest_max[rep] <- AvgPower_max;
    TestStat_Min[rep] <- TestStatistic_min;
    TestStat_Max[rep] <- TestStatistic_max;
    LambdaHat[rep] <- LambdaEst;
    min_betaS[rep] <- beta_s[which.min(abs(beta_s))];
    min_betaShat[rep] <- minbetaShat;
    max_betaU[rep] <- beta_u[which.max(abs(beta_u))];
  } else{
    MABpcr[rep] <- NA;
    MABlinearReg[rep] <- NA;
    MABridge[rep] <- NA;
    MABlasso[rep] <- NA;
    MABnew[rep] <- NA;
    sigma2pcr[rep] <- NA;
    sigma2linearReg[rep] <- NA;
    sigma2ridge[rep] <- NA;
    sigma2lasso[rep] <- NA;
    sigma2new[rep] <- NA;
    MSPEpcr[rep] <- NA;
    MSPElinearReg[rep] <- NA;
    MSPEridge[rep] <- NA;
    MSPElasso[rep] <- NA;
    MSPEnew[rep] <- NA;
    AvgCovCI[rep]  <- NA;
    AvgLengthCI[rep] <- NA;
    AvgPowerTest_min[rep] <- NA;
    AvgPowerTest_max[rep] <- NA;
    TestStat_Min[rep] <- NA;
    TestStat_Max[rep] <- NA;
    LambdaHat[rep] <- NA;
    min_betaS[rep] <- NA;
    min_betaShat[rep] <- NA;
    max_betaU[rep] <- NA;
    kk[rep] <- NA;
  }
  
  whole_results <- cbind(MABpcr,MABlinearReg,sigma2pcr,sigma2linearReg,MSPEpcr,MSPElinearReg,MABridge,MABlasso,MABnew,sigma2ridge,sigma2lasso,sigma2new,
                         MSPEridge,MSPElasso,MSPEnew,AvgCovCI,AvgLengthCI,AvgPowerTest_min,AvgPowerTest_max,
                         TestStat_Min,TestStat_Max,LambdaHat,nn,p,pstar,nselcov,kk,min_betaS,min_betaShat,max_betaU);
  
  write.table(whole_results,file="whole_n100p500pstar20.csv",
              row.names=FALSE, col.names=c("MABpcr","MABlinearReg","sigma2pcr","sigma2linearReg",
                                           "MSPEpcr","MSPElinearReg","MABridge","MABlasso","MABnew","sigma2ridge",
                                           "sigma2lasso","sigma2new","MSPEridge","MSPElasso","MSPEnew",
                                           "AvgCovCI","AvgLengCI","AvgPowerMin","AvgPowerMax","TestStat_Min",
                                           "TestStat_Max","LambdaHat","n","p","pstar","nselcov","k",
                                           "min_betaS","min_betaShat","max_betaU"), sep=",");
}

#final simulation results, that is, the averages over all simulation replications;
fMABpcr <- mean(MABpcr, na.rm=TRUE)
fMABlinearReg <- mean(MABlinearReg, na.rm=TRUE)
fMABridge <- mean(MABridge, na.rm=TRUE)
fMABlasso <- mean(MABlasso, na.rm=TRUE)
fMABnew <- mean(MABnew, na.rm=TRUE)

fsigma2pcr <- mean(sigma2pcr, na.rm=TRUE)
fsigma2linearReg <- mean(sigma2linearReg, na.rm=TRUE)
fsigma2ridge <- mean(sigma2ridge, na.rm=TRUE)
fsigma2lasso <- mean(sigma2lasso, na.rm=TRUE)
fsigma2new <- mean(sigma2new, na.rm=TRUE)

fMSPEpcr <- mean(MSPEpcr, na.rm=TRUE)
fMSPElinearReg <- mean(MSPElinearReg, na.rm=TRUE)
fMSPEridge <- mean(MSPEridge, na.rm=TRUE)
fMSPElasso <- mean(MSPElasso, na.rm=TRUE)
fMSPEnew <- mean(MSPEnew, na.rm=TRUE)

fAvgCovCI <- mean(AvgCovCI, na.rm=TRUE)
fAvgLengthCI <- mean(AvgLengthCI, na.rm=TRUE)
fAvgPowerTest_min <- mean(AvgPowerTest_min, na.rm=TRUE) 
fAvgPowerTest_max <- mean(AvgPowerTest_max, na.rm=TRUE) 
fTestStat_Min <- mean(abs(TestStat_Min), na.rm=TRUE)
fTestStat_Max <- mean(abs(TestStat_Max), na.rm=TRUE)
fLambdaHat <- median(LambdaHat, na.rm=TRUE)

fmin_betaS <- mean(abs(min_betaS), na.rm=TRUE)
fmin_betaShat <- mean(abs(min_betaShat), na.rm=TRUE)
fmax_betaU <- mean(abs(max_betaU), na.rm=TRUE)

fkk <- mean(kk, na.rm=TRUE)
fnselcov <- mean(nselcov, na.rm=TRUE)


############################################################################################################
############################################################################################################
############################################################################################################

# some final steps just for saving the output;
average_results <- cbind(fMABpcr,fMABlinearReg,fsigma2pcr,fsigma2linearReg,fMSPEpcr,fMSPElinearReg,fMABridge,fMABlasso,fMABnew,fsigma2ridge,fsigma2lasso,fsigma2new,
                         fMSPEridge,fMSPElasso,fMSPEnew,fAvgCovCI,fAvgLengthCI,fAvgPowerTest_min,fAvgPowerTest_max,
                         fTestStat_Min,fTestStat_Max,fLambdaHat,nn,p,pstar,fnselcov,fkk,fmin_betaS,fmin_betaShat,
                         fmax_betaU);

write.table(average_results,file="average_n100p500pstar20.csv",
            row.names=FALSE, col.names=c("MABpcr","MABlinearReg","sigma2pcr","sigma2linearReg",
                                         "MSPEpcr","MSPElinearReg","MABridge","MABlasso","MABnew","sigma2ridge",
                                         "sigma2lasso","sigma2new","MSPEridge","MSPElasso","MSPEnew","AvgCovCI","AvgLengCI",
                                         "AvgPowerMin","AvgPowerMax","TestStat_Min","TestStat_Max","LambdaHat","n","p","pstar", "nselcov","k",
                                         "min_betaS","min_betaShat","max_betaU"), sep=",");



cat("Below are the average bias of the parameter estimates as well as the prediction error of the E-PoS model, lasso and ridge regression. Also, the E-PoS confidence intervals and hypothesis tests are reporetd below as descibed in the simulations section of the paper");

MABpcr
MABlinearReg
MABridge
MABlasso
MABnew
sigma2pcr
sigma2linearReg
sigma2ridge
sigma2lasso
sigma2new
MSPEpcr
MSPElinearReg
MSPEridge
MSPElasso
MSPEnew
AvgCovCI
AvgLengthCI
AvgPowerTest_min
AvgPowerTest_max
TestStat_Min
TestStat_Max
LambdaHat
nselcov

kk




