#The whole code here takes about 14 minutes to run;
#Note that p=4088 in the riboflavin data;
#################################################
library(MASS);
library(glmnet);
library(pls);
library(mvtnorm);
library(tmvtnorm);
library(expm);
library(optimx);
library(numDeriv);
library(miscTools);
library(ggplot2);
library(latex2exp);
#################################################

set.seed(1)

#To import the riboflavin data from computer;
data1 <- read.csv(file="riboflavin.csv", header=TRUE)
protein_data <- data1[,-1]
protein_data <- data.matrix(protein_data)
protein_data <- t(protein_data) 

X <- protein_data[,-1]
row.names(X) <- NULL
Y <- protein_data[,1] #the first column is the response variable;
names(Y) <- NULL

n <- length(Y)
p <- ncol(X)

X.train <- X; #Note here that X.train just refers the whole X data; 
#to centre all the X variables;
X.train <- as.matrix(scale(X.train, scale=FALSE)); 
dimnames(X.train) <- list(rownames(X.train, do.NULL = TRUE),colnames(X.train, do.NULL = FALSE, prefix = "X"))
Y.train <- Y; #Note here that Y.train just refers to the whole Y data;

#A function to obtain "Index_of_Xs", "Signs" and "Lambda_Lasso", which are needed for the main function called "EPoS_conditional";
Function_Index_of_Xs_signs_Lasso <- function(X.train,Y.train)
{
  nn <- nrow(X.train); #sample size as in the training data;
  dimnames(X.train) <- list(rownames(X.train, do.NULL = TRUE),colnames(X.train, do.NULL = FALSE, prefix = "X"));
  #to estimate sigma2 using CV in glmnet as in Reid et al (2016) - needed for lasso tuning parameter selection;
  M0 <- glmnet(X.train,Y.train, family="gaussian", alpha=1);
  CVL <- cv.glmnet(X.train,Y.train);
  LambdaMinCV <- CVL$lambda.min;
  betahatCV <- coef(M0, s=LambdaMinCV);
  bCVnew <- apply(betahatCV, 1, function(row) all(row !=0 ));
  estimateCV <- betahatCV[bCVnew,];
  estimateCV <- cbind(estimateCV);
  Index_XsCV <- row.names(estimateCV);
  Index_XsCV <- c(Index_XsCV);
  Index_XsCV <- gsub("[a-zA-Z ]", "", Index_XsCV);
  Index_XsCV <- Index_XsCV[-1];
  Index_XsCV <- as.numeric(Index_XsCV);
  q <- length(Index_XsCV); #the number of selected variables;
  Xs <- X.train[,1]; #just an initial assignment here to start the process of getting the selected covariates Xs;
  j <- Index_XsCV[1];
  for(i in 1:q)
   {
    j <- Index_XsCV[i+1]-i;
    Xs <- cbind(Xs,X.train[,Index_XsCV[i]]);
   }
  Xs <- Xs[,-1];
  Xs <- matrix(c(Xs),nn,q);
  dimnames(Xs) <- list(rownames(Xs, do.NULL = TRUE),colnames(Xs, do.NULL = FALSE, prefix = "Xs"));
  Int <- rep(1,nn);
  Xs <- cbind(Int,Xs); #add a column of ones for the intercept;
  sigma2CV <- t(Y.train-Xs%*%c(estimateCV))%*%((Y.train-Xs%*%c(estimateCV)))/(nn-(q+1));
  sigma2CV <- max(0,sigma2CV);  
  sigma2CV[sigma2CV==Inf] <- 0;
  #Negahban et al (2012) approach to the lambda selection using sigma2CV above; 
  I_n <- diag(nn,x=rep(1,nn));
  CovEps <- c(sigma2CV)*I_n;
  if(semidefiniteness(CovEps))
   {
    CovEps <- CovEps;
   } else
   {
    eigCovEps <- eigen(CovEps, symmetric = TRUE); 
    eigCovEps$values <- pmax(0, eigCovEps$values); 
    CovEps <- eigCovEps$vectors %*% diag(eigCovEps$values) %*% t(eigCovEps$vectors);
   }
  eps <- rmvnorm(10000,mean=rep(0,nn),sigma=CovEps);
  Xeps <- t(X.train)%*%t(eps);
  infitynorm_Xeps <- apply(Xeps,2,max);
  lambda_n <- 2*mean(infitynorm_Xeps)/nn;
  #lambda_n <- max(lambda_n,sqrt(log(p)/nn)); #Unlike simulations and predictions, we here ignore this just to possibly allow more variables to be selected for significance testing via the proposed simultaneous post-selection hypothesis test;
  #To get "Index_of_Xs" from the lasso with the above regularisation parameter lambda based on X.train and Y.train;
  M1 <- glmnet(X.train,Y.train, family="gaussian", alpha=1);
  betahat1 <- coef(M1, s=lambda_n);
  b1new <- apply(betahat1, 1, function(row) all(row!=0));
  estimate1 <- betahat1[b1new,];
  estimate1 <- cbind(estimate1);
  leng <- nrow(estimate1);
  if(leng>2)
  {
   lasso_est <- estimate1;
   #Index_Xs will be required for constructing Xs and Xu;
   Index_Xs <- row.names(estimate1);
   Index_Xs <- c(Index_Xs);
   Index_Xs <- gsub("[a-zA-Z ]", "", Index_Xs);
   #to remove the intercept estimate here for obtaining Xs;
   Index_Xs <- Index_Xs[-1];
   Index_Xs <- as.numeric(Index_Xs);
   #to get the signs of the lasso estimates;
   signs <- numeric(length(lasso_est));
   for(i in 1:length(lasso_est))
   {
    if(lasso_est[i]>=0){signs[i] <- 1}else{signs[i] <- -1}; 
   }
   return(list(Index_Xs,signs,lambda_n));
  } else{return(list(NA,NA,NA));}
}

# To obtain the "Index_of_Xs", "Signs" and "Lambda_Lasso" of the lasso for the data using the above function;
Lasso_Selection <- Function_Index_of_Xs_signs_Lasso(X.train,Y.train);
Index_of_Xs <- Lasso_Selection[[1]];
Signs <- Lasso_Selection[[2]];
Lambda_Lasso <- Lasso_Selection[[3]];

# The main function to apply the new method "E-PoS" to the data;
EPoS <- function(X.train,Y.train,Index_of_Xs,k)
{
  nn <- nrow(X.train); #sample size as in the training data;
  #Process of constructing Xs and Xu;
  Xu <- X.train; #just an initial assignment here to start the process;
  Xs <- X.train[,1]; #just an initial assignment here to start the process;
  Index_Xs <- Index_of_Xs;
  q <- length(Index_Xs); #the number of selected covariates excluding the intercept column;
  length_Index_Xs <- q; #the number of selected covariates excluding the intercept column;
  j <- Index_Xs[1];
  for(i in 1:length_Index_Xs)
   {
    Xu <- Xu[,-j];
    j <- Index_Xs[i+1]-i;
    Xs <- cbind(Xs,X.train[,Index_Xs[i]]);
   }
  Xs <- Xs[,-1];
  Xs <- matrix(c(Xs),nn,length_Index_Xs);
  dimnames(Xs) <- list(rownames(Xs, do.NULL = TRUE),colnames(Xs, do.NULL = FALSE, prefix = "Xs"));
  #to add a column of ones for the intercept;
  Int <- rep(1,nn);
  Xs <- cbind(Int,Xs); 
  Xs_WithoutIntercept <- Xs[,-1]; #not used here though;
  
  Xu_decomposition=svd(Xu,nv=ncol(Xu));

  if(ncol(Xu)-length(Xu_decomposition$d)!=0)
  {
    add1=matrix(0,length(Xu_decomposition$d),ncol(Xu)-length(Xu_decomposition$d));
    add2=matrix(0,ncol(Xu)-length(Xu_decomposition$d),ncol(Xu));
    U=cbind(Xu_decomposition$u,add1);
    D=rbind(cbind(diag(Xu_decomposition$d),add1),add2);
    P=U%*%D;
    V=Xu_decomposition$v;
  }else{
    U=Xu_decomposition$u;
    D=diag(Xu_decomposition$d);
    P=U%*%D;
    V=Xu_decomposition$v;
  }
  
  # for estimation in the E-PoS model and its bias evaluation;
  if(k>1 & k<ncol(U))
  {
    U_k <- U[,1:k];
    D_k <- D[1:k,1:k];
    V_k <- V[1:k,1:k];
    P_k <- P[,1:k];
  } else{
    U_k <- U;
    D_k <- D;
    V_k <- V;
    P_k <- P;
  }
  
  #To get initial values for parameters using the unconditional E-PoS approach; 
  #reparametrisation from lambda to log(lambda) to avoid parameter constraint in maximisation of the profile likelihood; 
  profile_likelihood <- function(par)
  {
    lambdaa <- exp(par); #the reparametrisation;
    I_n=diag(nn,x=rep(1,nn));
    Sigma_lambdaa <- I_n + (P_k%*%t(V_k)%*%V_k%*%t(P_k))*lambdaa; 
    H <- Xs%*%ginv(t(Xs)%*%ginv(Sigma_lambdaa)%*%Xs)%*%t(Xs)%*%ginv(Sigma_lambdaa);
    e <- (I_n-H)%*%Y.train;
    l_p=(-1/2)*(log(det(Sigma_lambdaa)))-(nn/2)*(log(t(e)%*%ginv(Sigma_lambdaa)%*%e));
    return(c(-l_p));
  }
  
  #First get the maximum likelihood estimate of lambda needed for the closed-form estimators of beta_s and sigma2 in the unconditional E-PoS approach; 
  #Add suppressWarnings here just to suppress warnings if one the many optimisation methods in "optimx" does not work - the best optimisation value will be chosen anyway;
  par_hat_unconditionalEPoS <- suppressWarnings(try(summary(optimx(0,profile_likelihood,control=list(all.methods=TRUE,kkt=FALSE,iter.max=10000)), order=value)[1,1],silent=TRUE));
  #par_hat_unconditionalEPoS <- suppressWarnings(try(nlminb(0,profile_likelihood,control=list(iter.max=10000))$par,silent=TRUE));
  if(typeof(par_hat_unconditionalEPoS)=="character")
  {
    lambda_initial <- 1;
    sigma2_initial <- 1;
    beta_s_initial <- c(ginv(t(Xs)%*%Xs)%*%t(Xs)%*%Y.train);
  } else{
    if(is.na(par_hat_unconditionalEPoS) | exp(par_hat_unconditionalEPoS)==0)
    {
      lambda_initial <- 1;
      sigma2_initial <- 1;
      beta_s_initial <- c(ginv(t(Xs)%*%Xs)%*%t(Xs)%*%Y.train);
    } else{ 
      #To calculate initial estimates from the unconditional E-PoS method;
      lambda_hat_unconditionalEPoS <- exp(par_hat_unconditionalEPoS);
      I_n=diag(nn,x=rep(1,nn));
      Sigma_lambda_hat_unconditionalEPoS <- I_n + (P_k%*%t(V_k)%*%V_k%*%t(P_k))*lambda_hat_unconditionalEPoS; 
      betahat_s_marginal_unconditionalEPoS <- ginv(t(Xs)%*%ginv(Sigma_lambda_hat_unconditionalEPoS)%*%Xs)%*%t(Xs)%*%ginv(Sigma_lambda_hat_unconditionalEPoS)%*%Y.train;
      sigma2_hat_marginal_unconditionalEPoS <- (1/nn)*t(Y.train-Xs%*%betahat_s_marginal_unconditionalEPoS)%*%ginv(Sigma_lambda_hat_unconditionalEPoS)%*%(Y.train-Xs%*%betahat_s_marginal_unconditionalEPoS);
      #the initial estimates to use for the conditional E-PoS method;
      beta_s_initial <- c(betahat_s_marginal_unconditionalEPoS);
      sigma2_initial <- c(sigma2_hat_marginal_unconditionalEPoS);
      lambda_initial <- c(lambda_hat_unconditionalEPoS);
    }}
  
  #to get the polyhedra from the lasso selected model;
  I_n <- diag(nn,x=rep(1,nn));
  Ip_q <- matrix(rep(1,p-q),p-q,1); 
  #Ip_q <- matrix(rep(1,p-(q+1)),p-(q+1),1); #Note: we used p-(q+1) in the simulations because +1 was added for the intercept column; 
  A1 <- t(Xu)%*%(I_n-Xs%*%ginv(t(Xs)%*%Xs)%*%t(Xs));
  A1 <- (1/(nn*Lambda_Lasso))*A1;
  A2 <- -A1;
  A3 <- -diag(Signs)%*%ginv(t(Xs)%*%Xs)%*%t(Xs);
  A <- rbind(A1,A2,A3);
  B1 <- Ip_q - t(Xu)%*%Xs%*%ginv(t(Xs)%*%Xs)%*%Signs;
  B2 <- Ip_q + t(Xu)%*%Xs%*%ginv(t(Xs)%*%Xs)%*%Signs;
  B3 <- -diag(Signs)%*%ginv(t(Xs)%*%Xs)%*%Signs;
  B3 <- (nn*Lambda_Lasso)*B3;
  B <- rbind(B1,B2,B3);
  #KKT1 <- max(A1%*%Y.train-B1); 
  #KKT2 <- max(A2%*%Y.train-B2); 
  #KKT3 <- max(A3%*%Y.train-B3);
  #max(A%*%Y.train-B);
  A <- A3;
  B <- B3;
  
  #to simulate the feasible region of the polyhedron;
  betaas <- beta_s_initial
  sigmaa2 <- sigma2_initial
  lambdaa <- lambda_initial
  I_n=diag(nn,x=rep(1,nn));
  Sigma_lambdaa <- I_n + (P_k%*%t(V_k)%*%V_k%*%t(P_k))*(lambdaa); 
  mean_y <- Xs%*%betaas;
  cov_y <- (sigmaa2)*Sigma_lambdaa;
  n_r <- 100000; #the number of simulated y;
  y_r <- rmvnorm(n_r,mean=c(mean_y),sigma=cov_y);
  y_f <- matrix(NA,n_r,nn);
  E <- numeric(n_r); #count how many times satisfy the polyhedra constraint;
  #check the polyhedra constraint for each simulated y;
  for(i in 1:n_r)
  {
    if(max(A%*%y_r[i,]-B)<=0)
    {
      y_f[i,] <- y_r[i,];
      E[i] <- 1;
    }else{
      y_f[i,] <- NA;
      E[i] <- NA;
    }
  }
  y_final <- y_f[rowSums(is.na(y_f))==0,];
  y_final2 <- t(as.matrix(y_final));
  if(length(y_final)>nn & nrow(y_final2)>1)
  {
    y_final <- y_f[rowSums(is.na(y_f))==0,];
    lo_lim <- apply(y_final, 2, FUN=min);
    up_lim <- apply(y_final, 2, FUN=max);
    ylim <-cbind(lo_lim,up_lim);
  }else{ylim <-cbind(rep(-Inf,nn),rep(Inf,nn));}
  
  #Maximum likelihood estimation for the conditional E-PoS method based on the truncated multivariate normal distribution;
  #reparametrisation to log(lambda) and log(sigma2) to avoid any parameter constraints in maximisation of the likelihood;
  conditional_EPoS_likelihood <- function(par)
  {
    lambdaa <- exp(par[1]); sigmaa2 <- exp(par[2]); betas <- par[-c(1:2)];
    I_n=diag(nn,x=rep(1,nn));
    Sigma_lambdaa <- I_n + (P_k%*%t(V_k)%*%V_k%*%t(P_k))*(lambdaa); 
    mean_y <- Xs%*%betas;
    cov_y <- (sigmaa2)*Sigma_lambdaa;
    #l_p <- dtmvnorm(x=c(Y.train),mean=c(mean_y),sigma=cov_y,lower=c(ylim[,1]),upper=c(ylim[,2]),log=TRUE);
    #l_p <- dtmvnorm(x=c(Y.train),mu=c(mean_y),sigma=cov_y,lb=c(ylim[,1]),ub=c(ylim[,2]),log=TRUE);
    l_p <- dmvnorm(x=Y.train,mean=c(mean_y),sigma=cov_y,log=TRUE)-log(pmvnorm(lower=c(ylim[,1]),upper=c(ylim[,2]),mean=c(mean_y),sigma=cov_y,maxpts=10000)[1]);
    return(c(-l_p));
  }
  
  #Add suppressWarnings here just to suppress warnings if one the many optimisation methods in "optimx" does not work - the best optimisation value will be chosen anyway;
  par_hat <- try(nlminb(c(log(lambda_initial),log(sigma2_initial),beta_s_initial),conditional_EPoS_likelihood,control=list(iter.max=10000))$par,silent=TRUE);
  #This uses "optimx" only if "nlminb" above fails to converge;
  if(typeof(par_hat)=="character")
  {
    npar <- length(beta_s_initial)+2; #total number of parameters to use in "optimx";
    par_hat <- suppressWarnings(try(summary(optimx(c(log(lambda_initial),log(sigma2_initial),beta_s_initial),conditional_EPoS_likelihood,control=list(all.methods=TRUE,kkt=FALSE,iter.max=10000)), order=value)[1,1:npar],silent=TRUE));
  }  
  
  if(typeof(par_hat)=="character")
  {
    cat("Convergence Error: the likelihood of the EPoS did not converge with k=",k,"It is recommended to use another value of k in the main R function called EPoS.");
    return(list(NA,NA,NA,NA,NA,NA,NA));
  } else{
    if(is.na(par_hat)[1]) #change to if(is.na(par_hat[1,1])) for optimx;
    {
     cat("Convergence Error: the likelihood of the EPoS did not converge with k=",k,"It is recommended to use another value of k in the main R function called EPoS.");
     return(list(NA,NA,NA,NA,NA,NA,NA));
    } else{
    par_hat <- as.vector(unlist(par_hat));
    lambda_hat <- exp(par_hat[1]);       
    sigma2_hat_marginal <- exp(par_hat[2]);
    betahat_s_marginal <- par_hat[-c(1:2)];
      
    #Covariance matrix of the beta_s estimates using the inverse of hessian matrix from the conditional E-PoS approach;
    #Method1;
    hessian_negative <- hessian(x=par_hat, func=conditional_EPoS_likelihood);
    var_betahat_s_marginal <- ginv(hessian_negative)[-c(1,2),-c(1,2)];
    #Method2-not used here;
    #hessian_negative2 <- gHgenb(par_hat, conditional_EPoS_likelihood)
    #var_betahat_s_marginal2 <- ginv(hessian_negative2$Hn)[-c(1,2),-c(1,2)];
    if(semidefiniteness(var_betahat_s_marginal))
    {
      var_betahat_s_marginal <- var_betahat_s_marginal;
    } else
    {
      eig <- eigen(var_betahat_s_marginal, symmetric = TRUE); 
      eig$values <- pmax(0, eig$values); 
      var_betahat_s_marginal <- eig$vectors %*% diag(eig$values) %*% t(eig$vectors);
    }
  
    #Conduct hypothesis tests and confience intervals for beta_s_j using the E-PoS approach;
    Significant <- numeric(length(betahat_s_marginal));
    p_value <- numeric(length(betahat_s_marginal));
    CI <- matrix(0,length(betahat_s_marginal),2);
    lenghts <- numeric(length(betahat_s_marginal));
    for(j in 1:length(betahat_s_marginal))
    {
      #conduct hypothesis test for beta_s_j;
      alpha <- 0.05;
      beta_hat_j <- betahat_s_marginal[j];
      sd_beta_hat_j <- sqrt(var_betahat_s_marginal[j,j]);
      test_stat_j <- (beta_hat_j)/sd_beta_hat_j;
      p_value[j] <- 2*(1-pnorm(abs(test_stat_j)));
      #simultaneous test using Bonferroni correction;
      if(p_value[j]<=alpha/length(betahat_s_marginal))
      {
        Significant[j] <- 1;
      } else
      {
        Significant[j] <- 0;
      } 
      #construct confidence interval for beta_s_j using Bonferroni correction;
      alpha_bonf <- alpha/(2*length(betahat_s_marginal));
      CI[j,] <- c(betahat_s_marginal[j]-qnorm(1-alpha_bonf,0,1)*sqrt(var_betahat_s_marginal[j,j]),betahat_s_marginal[j]+qnorm(1-alpha_bonf,0,1)*sqrt(var_betahat_s_marginal[j,j]));
      #calculate the length of the CI for beta_s_j;
      lenghts[j] <- CI[j,2]-CI[j,1]; 
    }}
    return(list(Significant,CI,Index_Xs,betahat_s_marginal,sigma2_hat_marginal,lambda_hat,k));
  }
}

#Cross validation for the proposed E-PoS method in order to select the optimal k;
CV_EPoS <- function(X.train,Y.train,X.test,Y.test,Index_of_Xs,k)
{
  nn <- nrow(X.train); #sample size as in the training data;
  #Process of constructing Xs and Xu;
  Xu <- X.train; #just an initial assignment here to start the process;
  Xs <- X.train[,1]; #just an initial assignment here to start the process;
  Index_Xs <- Index_of_Xs;
  q <- length(Index_Xs); #the number of selected covariates excluding the intercept column;
  length_Index_Xs <- q; #the number of selected covariates excluding the intercept column;
  j <- Index_Xs[1];
  for(i in 1:length_Index_Xs)
  {
    Xu <- Xu[,-j];
    j <- Index_Xs[i+1]-i;
    Xs <- cbind(Xs,X.train[,Index_Xs[i]]);
  }
  Xs <- Xs[,-1];
  Xs <- matrix(c(Xs),nn,length_Index_Xs);
  dimnames(Xs) <- list(rownames(Xs, do.NULL = TRUE),colnames(Xs, do.NULL = FALSE, prefix = "Xs"));
  #to add a column of ones for the intercept;
  Int <- rep(1,nn);
  Xs <- cbind(Int,Xs); 
  Xs_WithoutIntercept <- Xs[,-1]; #not used here though;
  
  Xu_decomposition=svd(Xu,nv=ncol(Xu));

  if(ncol(Xu)-length(Xu_decomposition$d)!=0)
  {
    add1=matrix(0,length(Xu_decomposition$d),ncol(Xu)-length(Xu_decomposition$d));
    add2=matrix(0,ncol(Xu)-length(Xu_decomposition$d),ncol(Xu));
    U=cbind(Xu_decomposition$u,add1);
    D=rbind(cbind(diag(Xu_decomposition$d),add1),add2);
    P=U%*%D;
    V=Xu_decomposition$v;
  }else{
    U=Xu_decomposition$u;
    D=diag(Xu_decomposition$d);
    P=U%*%D;
    V=Xu_decomposition$v;
  }
  
  # for estimation in the E-PoS model and its bias evaluation;
  if(k>1 & k<ncol(U))
  {
    U_k <- U[,1:k];
    D_k <- D[1:k,1:k];
    V_k <- V[1:k,1:k];
    P_k <- P[,1:k];
  } else{
    U_k <- U;
    D_k <- D;
    V_k <- V;
    P_k <- P;
  }
  
  #To get initial values for parameters using the unconditional E-PoS approach; 
  #reparametrisation from lambda to log(lambda) to avoid parameter constraint in maximisation of the profile likelihood; 
  profile_likelihood <- function(par)
  {
    lambdaa <- exp(par); #the reparametrisation;
    I_n=diag(nn,x=rep(1,nn));
    Sigma_lambdaa <- I_n + (P_k%*%t(V_k)%*%V_k%*%t(P_k))*lambdaa; 
    H <- Xs%*%ginv(t(Xs)%*%ginv(Sigma_lambdaa)%*%Xs)%*%t(Xs)%*%ginv(Sigma_lambdaa);
    e <- (I_n-H)%*%Y.train;
    l_p=(-1/2)*(log(det(Sigma_lambdaa)))-(nn/2)*(log(t(e)%*%ginv(Sigma_lambdaa)%*%e));
    return(c(-l_p));
  }
  
  par_hat_unconditionalEPoS <- suppressWarnings(try(nlminb(0,profile_likelihood,control=list(iter.max=10000))$par,silent=TRUE));

  if(typeof(par_hat_unconditionalEPoS)=="character")
  {
   return(NA);
  } else{
  if(exp(par_hat_unconditionalEPoS)==0)
  {
   return(NA);
  } else{
  #To calculate initial estimates from the unconditional E-PoS method;
  lambda_hat_unconditionalEPoS <- exp(par_hat_unconditionalEPoS);
  I_n=diag(nn,x=rep(1,nn));
  Sigma_lambda_hat_unconditionalEPoS <- I_n + (P_k%*%t(V_k)%*%V_k%*%t(P_k))*lambda_hat_unconditionalEPoS; 
  betahat_s_marginal_unconditionalEPoS <- ginv(t(Xs)%*%ginv(Sigma_lambda_hat_unconditionalEPoS)%*%Xs)%*%t(Xs)%*%ginv(Sigma_lambda_hat_unconditionalEPoS)%*%Y.train;
  sigma2_hat_marginal_unconditionalEPoS <- (1/nn)*t(Y.train-Xs%*%betahat_s_marginal_unconditionalEPoS)%*%ginv(Sigma_lambda_hat_unconditionalEPoS)%*%(Y.train-Xs%*%betahat_s_marginal_unconditionalEPoS);
  #the initial estimates to use for the conditional E-PoS method;
  beta_s_initial <- c(betahat_s_marginal_unconditionalEPoS);
  sigma2_initial <- c(sigma2_hat_marginal_unconditionalEPoS);
  lambda_initial <- c(lambda_hat_unconditionalEPoS);
  
  #to get the polyhedra from the lasso selected model;
  I_n <- diag(nn,x=rep(1,nn));
  Ip_q <- matrix(rep(1,p-q),p-q,1); 
  #Ip_q <- matrix(rep(1,p-(q+1)),p-(q+1),1); #Note: we used p-(q+1) in the simulations because +1 was added for the intercept column; 
  A1 <- t(Xu)%*%(I_n-Xs%*%ginv(t(Xs)%*%Xs)%*%t(Xs));
  A1 <- (1/(nn*Lambda_Lasso))*A1;
  A2 <- -A1;
  A3 <- -diag(Signs)%*%ginv(t(Xs)%*%Xs)%*%t(Xs);
  A <- rbind(A1,A2,A3);
  B1 <- Ip_q - t(Xu)%*%Xs%*%ginv(t(Xs)%*%Xs)%*%Signs;
  B2 <- Ip_q + t(Xu)%*%Xs%*%ginv(t(Xs)%*%Xs)%*%Signs;
  B3 <- -diag(Signs)%*%ginv(t(Xs)%*%Xs)%*%Signs;
  B3 <- (nn*Lambda_Lasso)*B3;
  B <- rbind(B1,B2,B3);
  #KKT1 <- max(A1%*%Y.train-B1); 
  #KKT2 <- max(A2%*%Y.train-B2); 
  #KKT3 <- max(A3%*%Y.train-B3);
  #max(A%*%Y.train-B);
  A <- A3;
  B <- B3;
  
  #to simulate the feasible region of the polyhedron;
  betaas <- beta_s_initial
  sigmaa2 <- sigma2_initial
  lambdaa <- lambda_initial
  I_n=diag(nn,x=rep(1,nn));
  Sigma_lambdaa <- I_n + (P_k%*%t(V_k)%*%V_k%*%t(P_k))*(lambdaa); 
  mean_y <- Xs%*%betaas;
  cov_y <- (sigmaa2)*Sigma_lambdaa;
  n_r <- 100000; #the number of simulated y;
  y_r <- rmvnorm(n_r,mean=c(mean_y),sigma=cov_y);
  y_f <- matrix(NA,n_r,nn);
  E <- numeric(n_r); #count how many times satisfy the polyhedra constraint;
  #check the polyhedra constraint for each simulated y;
  for(i in 1:n_r)
  {
    if(max(A%*%y_r[i,]-B)<=0)
    {
      y_f[i,] <- y_r[i,];
      E[i] <- 1;
    }else{
      y_f[i,] <- NA;
      E[i] <- NA;
    }
  }
  y_final <- y_f[rowSums(is.na(y_f))==0,];
  y_final2 <- t(as.matrix(y_final));
  if(length(y_final)>nn & nrow(y_final2)>1)
  {
    y_final <- y_f[rowSums(is.na(y_f))==0,];
    lo_lim <- apply(y_final, 2, FUN=min);
    up_lim <- apply(y_final, 2, FUN=max);
    ylim <-cbind(lo_lim,up_lim);
  }else{ylim <-cbind(rep(-Inf,nn),rep(Inf,nn));}
  
  #Maximum likelihood estimation for the conditional E-PoS method based on the truncated multivariate normal distribution;
  #reparametrisation to log(lambda) and log(sigma2) to avoid any parameter constraints in maximisation of the likelihood;
  conditional_EPoS_likelihood <- function(par)
  {
    lambdaa <- exp(par[1]); sigmaa2 <- exp(par[2]); betas <- par[-c(1:2)];
    I_n=diag(nn,x=rep(1,nn));
    Sigma_lambdaa <- I_n + (P_k%*%t(V_k)%*%V_k%*%t(P_k))*(lambdaa); 
    mean_y <- Xs%*%betas;
    cov_y <- (sigmaa2)*Sigma_lambdaa;
    #l_p <- dtmvnorm(x=c(Y.train),mean=c(mean_y),sigma=cov_y,lower=c(ylim[,1]),upper=c(ylim[,2]),log=TRUE);
    #l_p <- dtmvnorm(x=c(Y.train),mu=c(mean_y),sigma=cov_y,lb=c(ylim[,1]),ub=c(ylim[,2]),log=TRUE);
    l_p <- dmvnorm(x=Y.train,mean=c(mean_y),sigma=cov_y,log=TRUE)-log(pmvnorm(lower=c(ylim[,1]),upper=c(ylim[,2]),mean=c(mean_y),sigma=cov_y,maxpts=10000)[1]);
    return(c(-l_p));
  }
  
  #Add suppressWarnings here just to suppress warnings if one the many optimisation methods in "optimx" does not work - the best optimisation value will be chosen anyway;
  par_hat <- try(nlminb(c(log(lambda_initial),log(sigma2_initial),beta_s_initial),conditional_EPoS_likelihood,control=list(iter.max=10000))$par,silent=TRUE);
  
  if(typeof(par_hat)=="character")
  {
   return(NA);
  } else{
   if(exp(par_hat[1])==0)
   {
    return(NA);
   } else{
   lambda_hat <- exp(par_hat[1]);
   sigma2_hat_marginal <- exp(par_hat[2]);
   betahat_s_marginal <- par_hat[-c(1:2)];
    
   # compute the prediction error on validation data;
   n_testCV <- nrow(X.test);
   Xu_test <- X.test;
   j=Index_Xs[1];
   Xs_test <- X.test[,1];
   for(i in 1:length_Index_Xs)
   {
     Xu_test=Xu_test[,-j];
     j=Index_Xs[i+1]-i;
     Xs_test=cbind(Xs_test,X.test[,Index_Xs[i]]);
   }
   Xs_test <- Xs_test[,-1];
   #to add a column of ones for the intercept;
   Int_test <- rep(1,n_testCV);
   Xs_test <- cbind(Int_test,Xs_test); #add a column of ones for the intercept;
    
   Xu_test_decomposition=svd(Xu_test,nv=ncol(Xu_test));
    
   if(ncol(Xu_test)-length(Xu_test_decomposition$d)!=0)
   {
     add1_test=matrix(0,length(Xu_test_decomposition$d),ncol(Xu_test)-length(Xu_test_decomposition$d));
     add2_test=matrix(0,ncol(Xu_test)-length(Xu_test_decomposition$d),ncol(Xu_test));
     U_test=cbind(Xu_test_decomposition$u,add1_test);
     D_test=rbind(cbind(diag(Xu_test_decomposition$d),add1_test),add2_test);
     P_test=U_test%*%D_test;
     V_test=Xu_test_decomposition$v;
   }else{
     U_test=Xu_test_decomposition$u;
     D_test=diag(Xu_test_decomposition$d);
     P_test=U_test%*%D_test;
     V_test=Xu_test_decomposition$v;
   }
   
   if(k>1 & k<ncol(U_test))
   {
     U_k_test <- U_test[,1:k];
     D_k_test <- D_test[1:k,1:k];
     V_k_test <- V_test[1:k,1:k];
     P_k_test <- P_test[,1:k];
   }else{
     U_k_test <- U_test;
     D_k_test <- D_test;
     V_k_test <- V_test;
     P_k_test <- P_test;
   }
    
   # Prediction for the validation data;
   I_n=diag(nn,x=rep(1,nn));
   Sigma_lambda_hat <- I_n + (P_k%*%t(V_k)%*%V_k%*%t(P_k))*lambda_hat;
   b_k_hat <- lambda_hat*(V_k%*%t(P_k)%*%ginv(Sigma_lambda_hat))%*%(Y.train-Xs%*%betahat_s_marginal);
   Yhat_NewMethodCV <- Xs_test%*%betahat_s_marginal + P_k_test%*%t(V_k_test)%*%b_k_hat;
   MSPE_NewMethodCV <- mean((Y.test - Yhat_NewMethodCV)^2);        
   return(MSPE_NewMethodCV);
  }}}}
}



 # 10-fold cross validation to select k for the new method "E-PoS";
 CVresults <- c(0,0); 
 q <- length(Index_of_Xs); #the number of selected variables by ignoring the intercept;
 k_min <- 10; #minimun value to search for an optimal K using CV;
 k_max <- 400; #maximum value to search for an optimal K using CV, which would be checked below considering the size of training data;
 k_step <- 23; #step to search for optimal k, which would be checked below considering the size of training data;
 k_max2 <- min(k_max,p-q); #to avoid overrunning in low-dimensional situations;
 divide <- 1;
 #just to ensure we have enough number of possible k in the search for an optimal k;
 while(length(seq(k_min,k_max2,k_step))<15)
 {
   k_step <- k_step/divide; 
   divide <- divide+1; #increase divide to help get a smaller k_step if needed; 
 }
 for(k in floor(seq(k_min,k_max2,k_step))){
  #Randomly shuffle the train data to partition for CV;
  X.trainCV <- X.train[sample(nrow(X.train)),];
  Y.trainCV <- Y.train[sample(length(Y.train))];
  #Create 10 equally size folds;
  breaks <- nrow(X.trainCV)*0.1;
  folds <- cut(seq(1,nrow(X.trainCV)),breaks=breaks,labels=FALSE);
  
  #Perform 10 fold cross validation;
  MSPE_CV <- numeric(breaks);
  for(i in 1:breaks){
    #Segement your data by fold using the which() function; 
    testIndexes <- which(folds==i,arr.ind=TRUE);
    XtrainCV_train <- X.trainCV[-testIndexes, ];
    XtrainCV_valid <- X.trainCV[testIndexes, ];
    YtrainCV_train <-  Y.trainCV[-testIndexes];
    YtrainCV_valid <-  Y.trainCV[testIndexes];
    MSPE_CV[i] <- CV_EPoS(X.train=XtrainCV_train,Y.train=YtrainCV_train,X.test=XtrainCV_valid,Y.test=YtrainCV_valid,Index_of_Xs=Index_of_Xs,k=k);
  }
  if(length(na.omit(MSPE_CV)) < floor(breaks))
  {
    kCV <- c(k,NA);
  } else{
    kCV <- c(k,mean(MSPE_CV, na.rm=TRUE));
  }
  CVresults <- rbind(CVresults,kCV);
 }

 if(nrow(CVresults)>1){
  CVresult <- CVresults;
  CVresult <- CVresult[order(CVresult[,2]),];
  CVresult <- CVresult[complete.cases(CVresult),];
  CVresult <- as.matrix(CVresult);
  CVresult <- t(CVresult);
  if(!is.null(nrow(CVresult)) & nrow(CVresult)>1)
  {
    CVresult <- CVresults;
    CVresult <- CVresult[order(CVresult[,2]),];
    CVresult <- CVresult[complete.cases(CVresult),];
    CVresult <- matrix(CVresult,nrow(CVresult),2);
    stopvalue <- NA;
    i=2;
    while(is.na(stopvalue))
    {
      kk <- CVresult[i,1];
      kkk = kk;
      Results_EPoS <- EPoS(X.train=X.train,Y.train=Y.train,Index_of_Xs=Index_of_Xs,k=kkk);
      stopvalue <- Results_EPoS[[1]][1];
      i <- i+1;
      if(i>=nrow(CVresult))
      {
        break;
      }
    }
  }
}


#=============================================================
#printing the final results;
#=============================================================

cat("The indices of selected covariates Xs from the lasso are equal to:", Results_EPoS[[3]]);

cat("The E-PoS estimates of the regression parameters beta_s are as equal to:", Results_EPoS[[4]]);

cat("The E-PoS estimate of sigma2 is equal to:", c(Results_EPoS[[5]]));

cat("The E-PoS estimate of lambda is equal to:", c(Results_EPoS[[6]]));

cat("The selected number of principal components k from the cross validation is equal to:", c(Results_EPoS[[7]]));

cat("The E-PoS confidence intervals for regression parameters beta_s are:", Results_EPoS[[2]]);

cat("The E-PoS hypothesis tests (1 for significant) for regression parameters beta_s are:", Results_EPoS[[1]]);


#=============================================================
#plot for the E-PoS confidence intervals;
#=============================================================
significant_genes <- Results_EPoS[[1]][-1];
zero <- rep(0,q);
group <- numeric(q);
for(i in 1:q)
 {
  if(significant_genes[i]==1)
   {
    group[i] <- 1;
   }else{group[i] <- 0;}
 }
group <- c(factor(group));
limits <- cbind(c(Index_of_Xs),zero,Results_EPoS[[2]][-1,],c(group));
limits <- data.frame(limits);
limits$gene <- factor(limits$V1,levels=c("73",  "624", "1123", "1278", "1297", "1303", 
                                         "1312", "1503", "1516", "1639", "1762", "1820",
                                         "1996", "2564", "3514", "4003", "4004"));

ggplot(data=limits, aes(x=gene,y=0, ymin=V3, ymax=V4))+
  geom_pointrange(aes(col=V5),size=0.5,fatten=4)+
  #geom_hline(aes(fill=V5),yintercept =1, linetype=2)+
  xlab('Selected gene')+ ylab("95% post-selection confidence interval")+
  geom_errorbar(aes(ymin=V3, ymax=V4,col=V5),width=0.5,cex=1)+ 
  #facet_wrap(~V1,strip.position="left",scales = "free_y") +
  theme(plot.title=element_text(size=19,face="bold",angle=180),
        #axis.ticks.y=element_blank(),
        axis.text.x=element_text(face="bold",size=14),
        axis.text.y=element_text(face="bold",size=14),
        axis.title=element_text(size=14,face="bold")) +
        scale_y_continuous(breaks = c(-1.5,-1,0,1,1.5)) +
        #strip.text.y = element_text(hjust=3,vjust = -1,angle=180,face="bold"))+
        theme(axis.title.x=element_text(vjust=-0.0,size = 18),axis.title.y=element_text(vjust=2.0,size = 18)) +
        theme(legend.title = element_blank(), axis.line=element_line(colour="black"), panel.background = element_rect(fill="white", colour="black")) +
        theme(legend.position="none",legend.background = element_rect(color = "grey", fill = "white", size = 1),
        legend.text=element_text(size=25)) + geom_hline(yintercept=0) +
        expand_limits(y=c(-1.5,1.5))+
        coord_flip()

