#R function to apply the conditional "E-PoS" method to other examples - simply change the simulated data step at the beginning;
#The code here may take a few minutes to run depending on the values of p and n;
###########################################################################################################################
library(MASS);
library(glmnet);
library(pls);
library(mvtnorm);
library(tmvtnorm)
library(expm);
library(optimx);
library(numDeriv);
library(miscTools);
library(plyr);
library(crayon);
###########################################################################################################################

n <- 150; #this will be split below: 67% for training data (i.e. 100) and 33% for test data;
p <- 500;  #the number of parameters - it would work for both p>>n and p<n;

#this step generates simulated data;
X <- matrix(rnorm(n*(p-1)),n,p-1); #generate the covariates X;
intercept <- rnorm(1); #the intercept;
beta <- rnorm(p-1);
pstar <- 5; #the sparsity index, e.g. s0<n/log(p) - here s0=5 covariates will have non-zero coefficients - it can be increased to s0=100 like the simulations;
for(j in (pstar+1):(p-1)){beta[j]<-0;} #to set all the other parameters to 0;
J <- rep(1,n); #column of 1 for the intercept term;
Y <- J*intercept + X%*%beta+rnorm(n);

#this step creates training and test data sets for prediction evaluation;
train_rows <- sample(1:n, 0.67*n); 
X.train <- X[train_rows, ];
dimnames(X.train) <- list(rownames(X.train, do.NULL = TRUE),colnames(X.train, do.NULL = FALSE, prefix = "X"));
X.test <- X[-train_rows, ];
dimnames(X.test) <- list(rownames(X.test, do.NULL = TRUE),colnames(X.test, do.NULL = FALSE, prefix = "X"));

Y.train <- Y[train_rows];
Y.test <- Y[-train_rows];

###############################################################################################################
# The "EPoS" function to apply the conditional "E-PoS" to a given high dimensional or low dimensional data set;
EPoS <- function(X.train,Y.train,X.test,Y.test)
{
  nn <- nrow(X.train); #sample size as in the training data;
  dimnames(X.train) <- list(rownames(X.train, do.NULL = TRUE),colnames(X.train, do.NULL = FALSE, prefix = "X"));
  dimnames(X.test) <- list(rownames(X.test, do.NULL = TRUE),colnames(X.test, do.NULL = FALSE, prefix = "X"));

  #Negahban et al (2012) approach to the lambda selection; 
  I_n <- diag(nn,x=rep(1,nn));
  sigma2 <- 1; #Note that sigma2 is known in simulations unlike the real data application where we used sigma2CV;
  eps <- rmvnorm(10000,mean=rep(0,nn),sigma=sigma2*I_n);
  Xeps <- t(X.train)%*%t(eps);
  infitynorm_Xeps <- apply(Xeps,2,max);
  lambda_n <- 2*mean(infitynorm_Xeps)/nn;
  Lambda_Lasso <- lambda_n;
  #Apply lasso to get "Index_of_Xs" and an optimal Lambda_Lasso based on X.train and Y.train;
  M1 <- glmnet(X.train,Y.train, family="gaussian", alpha=1);
  betahat1 <- coef(M1, s=Lambda_Lasso);
  b1new <- apply(betahat1, 1, function(row) all(row!=0));
  estimate1 <- betahat1[b1new,];
  estimate1 <- cbind(estimate1);
  leng <- length(estimate1);
  lasso_est <- estimate1;
  #Index_Xs will be required for constructing Xs and Xu;
  Index_Xs <- row.names(estimate1);
  Index_Xs <- c(Index_Xs);
  Index_Xs <- gsub("[a-zA-Z ]", "", Index_Xs);
  Index_Xs <- Index_Xs[-1];
  Index_Xs <- as.numeric(Index_Xs);
  q <- length(Index_Xs); #the number of selected covariates excluding the intercept column;
  
  if(q==0)
  {
   cat(red("For this dataset, the lasso did not select any covariates. Therefore, the E-PoS method was not applied."));
  } else{
  #to get the signs of the lasso estimates;
  Signs <- numeric(length(lasso_est));
  for(i in 1:length(lasso_est))
  {
   if(lasso_est[i]>=0){Signs[i] <- 1}else{Signs[i] <- -1}; 
  }  
  #Process of constructing Xs and Xu;
  Xu <- X.train; #just an initial assignment here to start the process;
  Xs <- X.train[,1]; #just an initial assignment here to start the process;
  #Index_Xs <- Index_of_Xs;
  q <- length(Index_Xs); #the number of selected covariates excluding the intercept column;
  length_Index_Xs <- q; #the number of selected covariates excluding the intercept column;
  j <- Index_Xs[1];
  for(i in 1:length_Index_Xs)
  {
    Xu <- Xu[,-j];
    j <- Index_Xs[i+1]-i;
    Xs <- cbind(Xs,X.train[,Index_Xs[i]]);
  }
  Xs <- Xs[,-1];
  Xs <- matrix(c(Xs),nn,length_Index_Xs);
  dimnames(Xs) <- list(rownames(Xs, do.NULL = TRUE),colnames(Xs, do.NULL = FALSE, prefix = "Xs"));
  Int <- rep(1,nn);
  Xs <- cbind(Int,Xs); #add a column of ones for the intercept;
  Xs_WithoutIntercept <- Xs[,-1];
  
  Xu <- as.matrix(Xu);
  Xu_decomposition=svd(Xu,nv=ncol(Xu));
  
  if(ncol(Xu)-length(Xu_decomposition$d)!=0)
  {
   add1=matrix(0,length(Xu_decomposition$d),ncol(Xu)-length(Xu_decomposition$d));
   add2=matrix(0,ncol(Xu)-length(Xu_decomposition$d),ncol(Xu));
   U=cbind(Xu_decomposition$u,add1);
   D=rbind(cbind(diag(Xu_decomposition$d),add1),add2);
   P=U%*%D;
   V=Xu_decomposition$v;
  }else{
   U=Xu_decomposition$u;
   D=diag(Xu_decomposition$d);
   P=U%*%D;
   V=Xu_decomposition$v;
  }
  
  #unlike the simulations and real data which we used CV, we here calculate k automatically following Section 3 of the paper;
  k <- floor(10*log((q^2)*p/sqrt(nn)));  
  
  # for estimation in the E-PoS model and its bias evaluation;
  if(k>1 & k<ncol(U))
  {
   U_k <- U[,1:k];
   D_k <- D[1:k,1:k];
   V_k <- V[1:k,1:k];
   P_k <- P[,1:k];
  } else{
   U_k <- U;
   D_k <- D;
   V_k <- V;
   P_k <- P;
  }
  
  #To get initial values for parameters using the unconditional E-PoS approach; 
  #reparametrisation from lambda to log(lambda) to avoid parameter constraint in maximisation of the profile likelihood; 
  profile_likelihood <- function(par)
  {
    lambdaa <- exp(par); #the reparametrisation;
    I_n=diag(nn,x=rep(1,nn));
    Sigma_lambdaa <- I_n + (P_k%*%t(V_k)%*%V_k%*%t(P_k))*lambdaa; 
    H <- Xs%*%ginv(t(Xs)%*%ginv(Sigma_lambdaa)%*%Xs)%*%t(Xs)%*%ginv(Sigma_lambdaa);
    e <- (I_n-H)%*%Y.train;
    l_p=(-1/2)*(log(det(Sigma_lambdaa)))-(nn/2)*(log(t(e)%*%ginv(Sigma_lambdaa)%*%e));
    return(c(-l_p));
  }
  
  #First get the maximum likelihood estimate of lambda needed for the closed-form estimators of beta_s and sigma2 in the unconditional E-PoS approach; 
  #Add suppressWarnings here just to suppress warnings if one the many optimisation methods in "optimx" does not work - the best optimisation value will be chosen anyway;
  #par_hat_unconditionalEPoS <- suppressWarnings(try(summary(optimx(0,profile_likelihood,control=list(all.methods=TRUE,kkt=FALSE,iter.max=10000)), order=value)[1,1],silent=TRUE));
  par_hat_unconditionalEPoS <- suppressWarnings(try(nlminb(0,profile_likelihood,control=list(iter.max=10000))$par,silent=TRUE));
  if(typeof(par_hat_unconditionalEPoS)=="character")
  {
    lambda_initial <- 1;
    sigma2_initial <- 1;
    beta_s_initial <- c(ginv(t(Xs)%*%Xs)%*%t(Xs)%*%Y.train);
  } else{
    if(is.na(par_hat_unconditionalEPoS) | exp(par_hat_unconditionalEPoS)==0)
    {
      lambda_initial <- 1;
      sigma2_initial <- 1;
      beta_s_initial <- c(ginv(t(Xs)%*%Xs)%*%t(Xs)%*%Y.train);
    } else{ 
      #To calculate initial estimates from the unconditional E-PoS method;
      lambda_hat_unconditionalEPoS <- exp(par_hat_unconditionalEPoS);
      I_n=diag(nn,x=rep(1,nn));
      Sigma_lambda_hat_unconditionalEPoS <- I_n + (P_k%*%t(V_k)%*%V_k%*%t(P_k))*lambda_hat_unconditionalEPoS; 
      betahat_s_marginal_unconditionalEPoS <- ginv(t(Xs)%*%ginv(Sigma_lambda_hat_unconditionalEPoS)%*%Xs)%*%t(Xs)%*%ginv(Sigma_lambda_hat_unconditionalEPoS)%*%Y.train;
      sigma2_hat_marginal_unconditionalEPoS <- (1/nn)*t(Y.train-Xs%*%betahat_s_marginal_unconditionalEPoS)%*%ginv(Sigma_lambda_hat_unconditionalEPoS)%*%(Y.train-Xs%*%betahat_s_marginal_unconditionalEPoS);
      #the initial estimates to use for the conditional E-PoS method;
      beta_s_initial <- c(betahat_s_marginal_unconditionalEPoS);
      sigma2_initial <- c(sigma2_hat_marginal_unconditionalEPoS);
      lambda_initial <- c(lambda_hat_unconditionalEPoS);
    }}
  
  #to get the polyhedra from the lasso selected model;
  I_n <- diag(nn,x=rep(1,nn));
  Ip_q <- matrix(rep(1,p-(q+1)),p-(q+1),1); #we use p-(q+1) because +1 is added for the intercept column; 
  A1 <- t(Xu)%*%(I_n-Xs%*%ginv(t(Xs)%*%Xs)%*%t(Xs));
  A1 <- (1/(nn*Lambda_Lasso))*A1;
  A2 <- -A1;
  A3 <- -diag(Signs)%*%ginv(t(Xs)%*%Xs)%*%t(Xs);
  A <- rbind(A1,A2,A3);
  B1 <- Ip_q - t(Xu)%*%Xs%*%ginv(t(Xs)%*%Xs)%*%Signs;
  B2 <- Ip_q + t(Xu)%*%Xs%*%ginv(t(Xs)%*%Xs)%*%Signs;
  B3 <- -diag(Signs)%*%ginv(t(Xs)%*%Xs)%*%Signs;
  B3 <- (nn*Lambda_Lasso)*B3;
  B <- rbind(B1,B2,B3);
  #KKT1 <- max(A1%*%Y.train-B1); 
  #KKT2 <- max(A2%*%Y.train-B2); 
  #KKT3 <- max(A3%*%Y.train-B3);
  #max(A%*%Y.train-B);
  A <- A3;
  B <- B3;
  
  #to simulate the feasible region of the polyhedron;
  betaas <- beta_s_initial
  sigmaa2 <- sigma2_initial
  lambdaa <- lambda_initial
  I_n=diag(nn,x=rep(1,nn));
  Sigma_lambdaa <- I_n + (P_k%*%t(V_k)%*%V_k%*%t(P_k))*(lambdaa); 
  mean_y <- Xs%*%betaas;
  cov_y <- (sigmaa2)*Sigma_lambdaa;
  n_r <- 100000; #the number of simulated y;
  y_r <- rmvnorm(n_r,mean=c(mean_y),sigma=cov_y);
  y_f <- matrix(NA,n_r,nn);
  E <- numeric(n_r); #count how many times satisfy the polyhedra constraint;
  #check the polyhedra constraint for each simulated y;
  for(i in 1:n_r)
  {
    if(max(A%*%y_r[i,]-B)<=0)
    {
      y_f[i,] <- y_r[i,];
      E[i] <- 1;
    }else{
      y_f[i,] <- NA;
      E[i] <- NA;
    }
  }
  y_final <- y_f[rowSums(is.na(y_f))==0,];
  y_final2 <- t(as.matrix(y_final));
  if(length(y_final)>nn & nrow(y_final2)>1)
  {
    y_final <- y_f[rowSums(is.na(y_f))==0,];
    lo_lim <- apply(y_final, 2, FUN=min);
    up_lim <- apply(y_final, 2, FUN=max);
    ylim <-cbind(lo_lim,up_lim);
  }else{ylim <-cbind(rep(-Inf,nn),rep(Inf,nn));}
  
  #Maximum likelihood estimation for the conditional E-PoS method based on the truncated multivariate normal distribution;
  #reparametrisation to log(lambda) and log(sigma2) to avoid any parameter constraints in maximisation of the likelihood;
  conditional_EPoS_likelihood <- function(par)
  {
    lambdaa <- exp(par[1]); sigmaa2 <- exp(par[2]); betas <- par[-c(1:2)];
    I_n=diag(nn,x=rep(1,nn));
    Sigma_lambdaa <- I_n + (P_k%*%t(V_k)%*%V_k%*%t(P_k))*(lambdaa); 
    mean_y <- Xs%*%betas;
    cov_y <- (sigmaa2)*Sigma_lambdaa;
    #l_p <- dtmvnorm(x=c(Y.train),mean=c(mean_y),sigma=cov_y,lower=c(ylim[,1]),upper=c(ylim[,2]),log=TRUE);
    #l_p <- dtmvnorm(x=c(Y.train),mu=c(mean_y),sigma=cov_y,lb=c(ylim[,1]),ub=c(ylim[,2]),log=TRUE);
    l_p <- dmvnorm(x=Y.train,mean=c(mean_y),sigma=cov_y,log=TRUE)-log(pmvnorm(lower=c(ylim[,1]),upper=c(ylim[,2]),mean=c(mean_y),sigma=cov_y,maxpts=10000)[1]);
    return(c(-l_p));
  }
  
  #Add suppressWarnings here just to suppress warnings if one the many optimisation methods in "optimx" does not work - the best optimisation value will be chosen anyway;
  par_hat <- try(nlminb(c(log(lambda_initial),log(sigma2_initial),beta_s_initial),conditional_EPoS_likelihood,control=list(iter.max=10000))$par,silent=TRUE);
  
  if(typeof(par_hat)=="character")
  {
   cat(red("Use another value of k or find an optimal k using the Cross Validation in the main R code."));
  } else{
    par_hat <- as.vector(unlist(par_hat));
    lambda_hat <- exp(par_hat[1]);       
    sigma2_hat_marginal <- exp(par_hat[2]);
    betahat_s_marginal <- par_hat[-c(1:2)];
    
    neg2loglik <- 2*(conditional_EPoS_likelihood(par_hat));
    
    #Covariance matrix of the beta_s estimates using the inverse of hessian matrix from the conditional E-PoS approach;
    #Method1;
    hessian_negative <- hessian(x=par_hat, func=conditional_EPoS_likelihood);
    if(!is.na(sum(hessian_negative)) & sum(hessian_negative)!=Inf & sum(hessian_negative)!=-Inf)
    {
      var_betahat_s_marginal <- ginv(hessian_negative)[-c(1,2),-c(1,2)];
    } else
    {
      Sigma_lambda_hat <- I_n + (P_k%*%t(V_k)%*%V_k%*%t(P_k))*lambda_hat; 
      var_betahat_s_marginal <- sigma2_hat_marginal*ginv(t(Xs)%*%ginv(Sigma_lambda_hat)%*%Xs);
    }
    #Method2-not used here though;
    #hessian_negative2 <- gHgenb(par_hat, conditional_EPoS_likelihood)
    #var_betahat_s_marginal2 <- ginv(hessian_negative2$Hn)[-c(1,2),-c(1,2)];
    if(semidefiniteness(var_betahat_s_marginal))
    {
      var_betahat_s_marginal <- var_betahat_s_marginal;
    } else
    {
      eig <- eigen(var_betahat_s_marginal, symmetric = TRUE); 
      eig$values <- pmax(0, eig$values); 
      var_betahat_s_marginal <- eig$vectors %*% diag(eig$values) %*% t(eig$vectors);
    }
    
    #conduct hypothesis tests for beta_s using the E-PoS method;
    TestStat_EPoS <- numeric(length(betahat_s_marginal));
    pvalue_EPoS <- numeric(length(betahat_s_marginal));
    SE <- numeric(length(betahat_s_marginal));
    for(j in 1:length(betahat_s_marginal))
    {
      #conduct hypothesis test for beta_s_j;
      SE[j] <- sqrt(var_betahat_s_marginal[j,j]);
      TestStat_EPoS[j] <- (betahat_s_marginal[j])/SE[j];
      pvalue_EPoS[j] <- 2*(1-pnorm(abs(TestStat_EPoS[j])));
    }
    
    #Construct confience intervals for beta_s using the E-PoS approach;
    #CI <- matrix(0,length(betahat_s_marginal),2);
    #SE <- numeric(length(betahat_s_marginal));
    #significance <- numeric(length(betahat_s_marginal));
    #for(j in 1:length(betahat_s_marginal))
    #{
    #  CI[j,] <- c(betahat_s_marginal[j]-qnorm(0.995,0,1)*sqrt(var_betahat_s_marginal[j,j]),betahat_s_marginal[j]+qnorm(0.995,0,1)*sqrt(var_betahat_s_marginal[j,j]));
    #  SE[j] <- sqrt(var_betahat_s_marginal[j,j]);
    #}
    #significance <- apply(CI,1,function(x){prod(sign(x))<=0});
    #significance <- factor(significance);
    #significance <- tryCatch(revalue(significance, c("FALSE"="YES", "TRUE"="NO")));

    #########################################
    # for prediction error on the test data;
    #########################################
    n_test <- nrow(X.test);
    Xu_test <- X.test; #just an initial assignment;
    Xs_test <- X.test[,1]; #just an initial assignment;
    j=Index_Xs[1];
    for(i in 1:length_Index_Xs)
    {
      Xu_test=Xu_test[,-j];
      j=Index_Xs[i+1]-i;
      Xs_test=cbind(Xs_test,X.test[,Index_Xs[i]]);
    }
    Xs_test <- Xs_test[,-1];
    Int_test <- rep(1,n_test);
    Xs_test <- cbind(Int_test,Xs_test); #add a column of ones for the intercept;
    
    Xu_test <- as.matrix(Xu_test);
    Xu_test_decomposition=svd(Xu_test,nv=ncol(Xu_test));
    
    if(ncol(Xu_test)-length(Xu_test_decomposition$d)!=0)
    {
     add1_test=matrix(0,length(Xu_test_decomposition$d),ncol(Xu_test)-length(Xu_test_decomposition$d));
     add2_test=matrix(0,ncol(Xu_test)-length(Xu_test_decomposition$d),ncol(Xu_test));
     U_test=cbind(Xu_test_decomposition$u,add1_test);
     D_test=rbind(cbind(diag(Xu_test_decomposition$d),add1_test),add2_test);
     P_test=U_test%*%D_test;
     V_test=Xu_test_decomposition$v;
    }else{
     U_test=Xu_test_decomposition$u;
     D_test=diag(Xu_test_decomposition$d);
     P_test=U_test%*%D_test;
     V_test=Xu_test_decomposition$v;
    }
    
    if(k>1 & k<ncol(U_test))
    {
     U_k_test <- U_test[,1:k];
     D_k_test <- D_test[1:k,1:k];
     V_k_test <- V_test[1:k,1:k];
     P_k_test <- P_test[,1:k];
    }else{
     U_k_test <- U_test;
     D_k_test <- D_test;
     V_k_test <- V_test;
     P_k_test <- P_test;
    }
    
    # Prediction using the proposed method "E-PoS";
    I_n=diag(nn,x=rep(1,nn));
    Sigma_lambda_hat <- I_n + (P_k%*%t(V_k)%*%V_k%*%t(P_k))*lambda_hat;
    b_k_hat <- lambda_hat*(V_k%*%t(P_k)%*%ginv(Sigma_lambda_hat))%*%(Y.train-Xs%*%betahat_s_marginal);
    Yhat_EPoS <- Xs_test%*%betahat_s_marginal + P_k_test%*%t(V_k_test)%*%b_k_hat;
    MSPE_EPoS <- mean((Y.test - Yhat_EPoS)^2);
    

    betahat_s_marginal <- round(betahat_s_marginal, digits=6);
    SE <- round(SE, digits=6);
    TestStat_EPoS <- round(TestStat_EPoS, digits=6);
    pvalue_EPoS <- sprintf("%6.6f",pvalue_EPoS);

    results <- data.frame(cbind(c("Intercept",Index_Xs),c(betahat_s_marginal),c(SE),c(TestStat_EPoS)),c(pvalue_EPoS));
    colnames(results) <- c("Selected covariate", "Estimate", "Std.Error", "Test statistic","p-value");
    orig.names <- names(results);
    name.width <- max(sapply(names(results), nchar));
    names(results) <- format(names(results), width = name.width, justify = "centre");
    output <- format(results, width = name.width, justify = "centre");
    print(output,row.names=FALSE);
    
    cat("\n");
    cat("The estimate of sigma2 is", sigma2_hat_marginal);
    cat("\n");
    cat("The estimate of lambda is", lambda_hat);
    cat("\n");
    cat("The value of k is", k);
    cat("\n");
    cat("-2loglikelihood is equal to", neg2loglik);
    cat("\n");
    cat("\n");
    cat("The mean squared prediction error (MSPE) on the test data is", MSPE_EPoS);
    cat("\n");
    
    return(list(Selected_Covariates=c("Intercept",Index_Xs),Estimate=betahat_s_marginal,Std.Error=SE,sigma2_hat=sigma2_hat_marginal,lambda_hat=lambda_hat,k=k,neg2loglik=neg2loglik,MSPE=MSPE_EPoS));
    #out <- as.matrix(results);
    #out <- as.table(out);
    #return(out);
   }
  }
}
  
##############################################################################################
##############################################################################################

#Call the function "EPoS" above to apply the proposed E-PoS method and print the results; 
#Note that here k is calculated automatically within the code based on Section 3 of the paper;
output <- EPoS(X.train,Y.train,X.test,Y.test); 
output;
output$Estimate;
output$Std.Error;

